import { Outlet } from "react-router";



export default function DefaultLayout() {
  return (
    <div className="bg-img">
        <Outlet />
    </div>
  );
}